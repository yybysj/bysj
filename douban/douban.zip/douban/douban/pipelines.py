# -*- coding: utf-8 -*-

class DoubanPipeline(object):
    def process_item(self, item, spider):
        return item
